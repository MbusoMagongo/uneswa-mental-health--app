// import { Auth0Handler } from '@auth0/nextjs-auth0';

// const handler = Auth0Handler();

// export { handler as GET, handler as POST };
