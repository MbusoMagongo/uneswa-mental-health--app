<?php
header('Content-Type: application/json');
require 'middleware.php'; 

handleCORS(); 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateInput(['studentId', 'password']); 

    $conn = new mysqli('localhost', 'root', '', 'campus_health');
    if ($conn->connect_error) {
        handleError('Database connection failed');
    }

    $data = json_decode(file_get_contents("php://input"), true);
    $student_id = $data['studentId'] ?? '';
    $password = $data['password'] ?? '';

    $stmt = $conn->prepare("SELECT password FROM users WHERE student_id = ?");
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            session_start();
            $_SESSION['student_id'] = $student_id;
            echo json_encode(['success' => true, 'message' => 'Login successful']);
        } else {
            handleError('Invalid password');
        }
    } else {
        handleError('Student ID not found');
    }

    $stmt->close();
    $conn->close();
} else {
    handleError('Invalid request method');
}
?>
