
import HomePage from "./homepage/page";
import SignIn from "./signin/page";

export default function LandingPage()
 {

  

    return <SignIn />;
    
 
  
}
