<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

$conn = new mysqli('localhost', 'root', '', 'campus_health');

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$result = $conn->query("SELECT COUNT(*) as unreadCount FROM notifications WHERE is_read = 0");
$data = $result->fetch_assoc();

echo json_encode(['unreadCount' => $data['unreadCount']]);
$conn->close();
?>
