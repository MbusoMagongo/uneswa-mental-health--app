'use client';
import Image from "next/image";
import Head from "next/head";
import Link from "next/link";
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'glightbox/dist/css/glightbox.min.css';
import AOS from 'aos';
import 'aos/dist/aos.css';
import '../styles/css/main.css';
import { useEffect, useState } from 'react';



const handleLogout = async () => {
    sessionStorage.removeItem('student_id');
    await fetch('http://localhost:3000/logout', {
        method: 'POST',
        credentials: 'include',
    });
    window.location.href = '/signin';
};

interface Event {
    id: number;
    title: string;
    description: string;
    event_date: string;
    location: string;
}
interface Notification {
    id: number;
    message: string;
}

export default function HomePage() {
    const [events, setEvents] = useState<Event[]>([]);
    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState<string>('');
    const [unreadNotifications, setUnreadNotifications] = useState(0);
    const [showNotifications, setShowNotifications] = useState<boolean>(false);
    const [notifications, setNotifications] = useState<Notification[]>([
        { id: 1, message: "Reserved for Mental Health Workshop" },
        { id: 2, message: "Reserved for Stress Management Event" },
        { id: 3, message: "Reserved for Yoga Session" },
    ]);
    
 

    const fetchNotifications = async () => {
        try {
            const response = await fetch('http://localhost/campus_health_api/getNotifications.php');
            const data = await response.json();
            setUnreadNotifications(data.unreadCount);
        } catch (error) {
            console.error("Error fetching notifications:", error);
        }
    };

    useEffect(() => {
        
        const intervalId = setInterval(fetchNotifications, 60000);
        fetchNotifications(); 

        return () => clearInterval(intervalId);
    }, []);

   
    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const response = await fetch('http://localhost/campus_health_api/getEvents.php');
                const data = await response.json();
                setEvents(data);
            } catch (error) {
                console.error("Error fetching events:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchEvents();
    }, []);

    const handleReserve = async (eventId: number) => {
        const studentId = sessionStorage.getItem('student_id');
        setLoading(true);
        if (!studentId) {
            console.error("Student ID is missing");
            return;
        }
    
        try {
            const response = await fetch('http://localhost/campus_health_api/reserveEvent.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ eventId, studentId }),
            });
    
            
            if (response.ok) {
                const data = await response.json();
                sessionStorage.setItem('event_title', data.eventTitle); 
                setLoading(false);
                window.open('/pdfscreen', '_blank' ); 
            } else {
                console.error('Reservation failed:', response.statusText);
                setLoading(false);
            }
        } catch (error) {
            console.error("Error reserving event:", error);
            setLoading(false);
        }
    };

    useEffect(() => {
        AOS.init({
            duration: 1000,
            once: true,
            mirror: false,
        });
    }, []);
    const toggleNotifications = () => {
        setShowNotifications(!showNotifications);
    };


    

    return (
        <>
            <Head>
                <meta charSet="utf-8"/>
                <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
                <Link href="https://fonts.googleapis.com" rel="preconnect"/>
                <Link href="https://fonts.gstatic.com" rel="preconnect"/>
                <Link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet"/>
            </Head>

            <body className="index-page">
                <header id="header" className="header d-flex align-items-center position-relative">
                    <div className="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">
                        <a href="index.html" className="logo d-flex align-items-center">
                            <img src="/uneswalogo.png" alt="AgriCulture"/>
                            <h1 className="sitename">UNESWA MENTAL HEALTH</h1>
                        </a>
                        <nav id="navmenu" className="navmenu">
                            <ul>
                                <li><a href="lo" className="active">Home</a></li>
                                <li><a href="#aboutus">About Us</a></li>
                                <li><a href="#event">Events</a></li>
                                <li><Link href="#contacts">Contact</Link></li>
                                <li className="notification-container">
                                    <i className="bi bi-bell bell-icon" onClick={toggleNotifications}>
                                        {unreadNotifications > 0 && <span className="badge">{unreadNotifications}</span>}
                                    </i>
                                    {showNotifications && (
                                        <div className="notification-popup">
                                            <ul>
                                                {notifications.length > 0 ? (
                                                    notifications.map((notification) => (
                                                        <li key={notification.id}>{notification.message}</li>
                                                    ))
                                                ) : (
                                                    <li>No notifications</li>
                                                )}
                                            </ul>
                                        </div>
                                    )}
                                </li>
                

                                
                                <li className="dropdown">
                                    <a href="#"><span>Account</span> <i className="bi bi-chevron-down toggle-dropdown"></i></a>
                                    <ul>
                                        <li><a href="#" onClick={handleLogout}>Logout</a></li>        
                                    </ul>
                                </li>
                            </ul>
                            <i className="mobile-nav-toggle d-xl-none bi bi-list"></i>
                        </nav>
                    </div>
                </header>


                <main className="main">

                <section id="hero" className="hero section dark-background">

<div id="hero-carousel" className="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

  <div className="carousel-item active">
    <img src="/background.jpg" alt=""/>
    <div className="carousel-container">
      <h2>Empower Your Mind and Body with Campus Wellness Resources</h2>
      <p>Explore support, tools, and events designed to enhance your mental well being. Wheather seeking counselling, wellness workshops or peer support, were are here to help you thrive</p>
    </div>
  </div>
</div>

</section>

<section id="about-3" className="about-3 section">

<div className="container">
  <div className="row gy-4 justify-content-between align-items-center">
    <div className="col-lg-6 order-lg-2 position-relative" data-aos="zoom-out">
      <img src="/blog-3.jpg" alt="Image" className="img-fluid"/>
      <a href="https://www.youtube.com/watch?v=LXb3EKWsInQ" className="glightbox pulsating-play-btn">
        <span className="play"><i className="bi bi-play-fill"></i></span>
      </a>
    </div>
    <div className="col-lg-5 order-lg-1" data-aos="fade-up" data-aos-delay="100" >
      <h2 id ="aboutus" className="content-title mb-4">About Us</h2>
      <p className="mb-4">
        We are a UNESWA Students Platform that helps in managing students mental health and awareneass.
        We provide students with resources that can be accessible anytime, anywhere with their phones.

      </p>
      <ul className="list-unstyled list-check">
        <li>Mental Health Events</li>
        <li>Student Counselling Appointments</li>
        <li>Wellness Tips</li>
      </ul>

      <p>< Link href="#contact" className="btn-cta">Get in touch</Link></p>
    </div>
  </div>
</div>
</section>

                    <section id="event" className="event section">
                        <div className="container section-title" data-aos="zoom-out">
                            <h2>UPCOMING EVENTS</h2>
                            <p>Go through the upcoming events and reserve your seat</p>
                        </div>

                        <div className="container">
                            <div className="row gy-4">
                                {events.map((event) => (
                                    <div className="col-lg-4" key={event.id}  data-aos="fade-up" data-aos-delay="100" >
                                        <article className="position-relative h-120">
                                            {/* <div className="post-img position-relative overflow-hidden">
                                                <img src="/blog-6.jpg" className="img-fluid" alt=""/>
                                            </div> */}
                                            <div className="meta d-flex align-items-end">
                                                <span className="post-date">{new Date(event.event_date).toDateString()}</span>
                                                <div className="d-flex align-items-center">
                                                    <i className="bi bi-geo-alt"></i>
                                                    <span className="ps-2">{event.location}</span>
                                                </div>
                                            </div>
                                            <div className="post-content d-flex flex-column">
                                                <h3 className="post-title">{event.title}</h3>
                                                
                                                <button className="reserve-button" disabled={loading} onClick={() => handleReserve(event.id)}>  {loading ? 'Reserving...' : 'Reserve'}</button>
                                               
                                            </div>
                                        </article>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </section>
                    <section id="contact" className="contact section">

<div className="mb-5">
  {/* <iframe style="width: 100%; height: 400px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" allowfullscreen=""></iframe> */}
</div>

<div id="contacts" className="container" data-aos="fade">
<div className="container section-title" data-aos="zoom-out">
                            <h2>CONTACT THE COUNSELLOR</h2>
                            <p>Directly communucate with UNESWA Counsellor</p>
                        </div>

  <div className="row gy-5 gx-lg-5">

    <div className="col-lg-4">

      <div className="info">
        <h3>Get in touch</h3>
        <p>Communicate with the University Counsellor Mr Kunene, in order to get help Directly email him.</p>

        <div className="info-item d-flex">
          <i className="bi bi-geo-alt flex-shrink-0"></i>
          <div>
            <h4>Location:</h4>
            <p>UNESWA, Kwaluseni Campus Next to Lomawa Block</p>
          </div>
        </div>

        <div className="info-item d-flex">
          <i className="bi bi-envelope flex-shrink-0"></i>
          <div>
            <h4>Email:</h4>
            <p>mrkunene@kwmailuneswa.sz</p>
          </div>
        </div>

        <div className="info-item d-flex">
          <i className="bi bi-phone flex-shrink-0"></i>
          <div>
            <h4>Call:</h4>
            <p>7655 0532
            </p>
          </div>
        </div>

      </div>

    </div>

    <div className="col-lg-8">
      <form action="forms/contact.php" method="post" role="form" className="php-email-form">
        <div className="row">
          <div className="col-md-6 form-group">
            <input type="text" name="name" className="form-control" id="name" placeholder="Your Name" />
          </div>
          <div className="col-md-6 form-group mt-3 mt-md-0">
            <input type="email" className="form-control" name="email" id="email" placeholder="Your Email" />
          </div>
        </div>
        <div className="form-group mt-3">
          <input type="text" className="form-control" name="subject" id="subject" placeholder="Subject" />
        </div>
        <div className="form-group mt-3">
          <textarea className="form-control" name="message" placeholder="Message" ></textarea>
        </div>
        <div className="my-3">
          {/* <div className="loading">Loading</div>
          <div className="error-message"></div>
          <div className="sent-message">Your message has been sent. Thank you!</div> */}
        </div>
        <div className="text-center"><button type="submit">Send Message</button></div>
      </form>
    </div>

  </div>

</div>
</section>


                </main>

                <footer id="footer" className="footer dark-background">
                    <div className="copyright text-center">
                        <div className="container d-flex flex-column flex-lg-row justify-content-center justify-content-lg-between align-items-center">
                            <div className="d-flex flex-column align-items-center align-items-lg-start">
                                <div>© Copyright <strong><span>2024</span></strong>. All Rights Reserved</div>
                                <div className="credits">
                                    
                                </div>
                            </div>
                            <div className="social-links order-first order-lg-last mb-3 mb-lg-0">
                                <a href=""><i className="bi bi-twitter-x"></i></a>
                                <a href=""><i className="bi bi-facebook"></i></a>
                                <a href=""><i className="bi bi-instagram"></i></a>
                                <a href=""><i className="bi bi-linkedin"></i></a>
                            </div>
                        </div>
                    </div>
                </footer>
               
  <script src="/scripts/bootstrap/js/bootstrap.bundle.min.js"></script>
  
  <script src="/scripts/aos/aos.js"></script>
  <script src="/scripts/swiper/swiper-bundle.min.js"></script>
  <script src="/scripts/glightbox/js/glightbox.min.js"></script>

 
  <script src="/scripts/main.js" async></script>
            </body>
        </>
    );
}