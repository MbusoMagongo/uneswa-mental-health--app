"use client";
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Document, Page, Text, View, StyleSheet, PDFViewer, Image } from '@react-pdf/renderer';

const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    padding: 30,
    fontFamily: 'Helvetica',
  },
  header: {
    textAlign: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  title1: {
    fontSize: 18,
    marginBottom: 10,
  },
  title2: {
    fontSize: 16,
    marginBottom: 10,
    color: '#FF0000',
  },
  title3: {
    fontSize: 16,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  title4: {
    fontSize: 16,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  image: {
    width: '50%', // Adjust as necessary
    marginTop: 5,
    marginLeft: '25%',
  },
  Image2: {
    width: '12%',
    height: '10%',
    marginLeft: '42%',
    marginTop: 10,
  },
});

const PdfDocument = ({ studentId, reservationDate, qrCodeUrl }: { studentId: string; reservationDate: string; qrCodeUrl: string; }) => {
  return (
    <Document>
      <Page style={styles.page}>
        <View style={styles.header}>
          <Image src="/uneswalogo.png" style={styles.Image2} />
          <Text style={styles.title}>UNESWA MENTAL HEALTH APP</Text>
          <Text style={styles.title1}>Reservation Confirmation</Text>
          <Text style={styles.title2}>You have successfully reserved!</Text>
          <Image src={qrCodeUrl} style={styles.image} />
          <Text style={styles.title3}>Student ID: {studentId}</Text>
          <Text style={styles.title4}>Reservation Date: {reservationDate}</Text>
        </View>
      </Page>
    </Document>
  );
};

const PdfViewResource = () => {
  const searchParams = useSearchParams();
  const studentId = sessionStorage.getItem('student_id') || ''; // Ensure this is never null
  const reservationDate = new Date().toLocaleDateString(); // Current date for the reservation
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null); // State for QR code URL

  useEffect(() => {
    
    const fetchQRCode = async () => {
      const data = `Student ID: ${studentId}, Reservation Date: ${reservationDate}`;
      const response = await fetch(`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(data)}`);
      const url = response.url;
      setQrCodeUrl(url); 
    };

    if (studentId) {
      fetchQRCode();
    }
  }, [studentId, reservationDate]);

  if (!studentId) {
    return <div>No Student ID found. Please ensure you have a valid ID.</div>;
  }

  return (
    <PDFViewer width="100%" height="1000">
      {qrCodeUrl ? (
        <PdfDocument studentId={studentId} reservationDate={reservationDate} qrCodeUrl={qrCodeUrl} />
      ) : (
        <div>Loading QR Code...</div>
      )}
    </PDFViewer>
  );
};

export default PdfViewResource;