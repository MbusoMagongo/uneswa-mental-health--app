// app/api/countries/route.ts

import { NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

export async function GET() {

  try {
    const response = await fetch('http://localhost:5001/countries');
    if(!response.ok){
      throw new Error('Failed to fetch Countries');
    }
    const countries = await response.json(); 
    
    return NextResponse.json(countries);
  }catch (error) {
    console.error('Error fetching countries:', error);
    return NextResponse.json({error: 'Faied to fetch counties'}, {status: 500});
  }

  // const filePath = path.join(process.cwd(),'data', 'countries.txt');
  // const fileContents = await fs.readFile(filePath, 'utf8');
  // const countries = fileContents.split('\n').map(country => country.trim()).filter(country => country);
  
}