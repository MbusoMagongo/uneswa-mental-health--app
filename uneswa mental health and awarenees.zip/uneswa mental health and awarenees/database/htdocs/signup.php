<?php
header('Content-Type: application/json');
require 'middleware.php'; 

handleCORS();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateInput(['studentId', 'email', 'password']); 

    $conn = new mysqli('localhost', 'root', '', 'campus_health');
    if ($conn->connect_error) {
        handleError('Database connection failed');
    }

    $data = json_decode(file_get_contents("php://input"), true);
    $student_id = $data['studentId'] ?? '';
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("SELECT * FROM users WHERE student_id = ? OR email = ?");
    $stmt->bind_param("ss", $student_id, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        handleError('Student ID or email already exists');
    } else {
        $stmt = $conn->prepare("INSERT INTO users (student_id, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $student_id, $email, $hashed_password);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'User registered successfully']);
        } else {
            handleError('User registration failed');
        }
    }

    $stmt->close();
    $conn->close();
} else {
    handleError('Invalid request method');
}
?>
