<?php



function handleCORS() {
    header("Access-Control-Allow-Origin: http://localhost:3000");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type");
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        exit(0);
    }
}


function validateInput($requiredFields) {
    $data = json_decode(file_get_contents("php://input"), true);
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            handleError("$field is required.");
        }
    }
}


function handleError($error) {
    echo json_encode(['success' => false, 'message' => $error]);
    exit;
}
?>
