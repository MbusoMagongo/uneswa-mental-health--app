"use client";
import { useRouter } from 'next/navigation';
import { useState } from "react";
import Head from "next/head";
import Link from "next/link";
import '../styles/css/signin.css';

export default function SignIn() {
    const [studentId, setStudentId] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const [isLogin, setIsLogin] = useState(true);
    const [loading, setLoading] = useState(false);

    const router = useRouter();

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const response = await fetch('http://localhost/campus_health_api/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ studentId, password }),
            });

            const data = await response.json();
            console.log(data);

            if (data.success) {
                sessionStorage.setItem('student_id', studentId);
                setMessage(data.message || "Login successful.");
                window.location.href = "/homepage";
            } else {
                setMessage(data.message || "An unknown error occurred."); // Update here to use data.message
            }
        } catch (error) {
            console.error("Error during login:", error);
            setMessage("An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const handleSignUp = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const response = await fetch('http://localhost/campus_health_api/signup.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ studentId, email, password }),
            });

            const data = await response.json();
            console.log(data);

            if (data.success) {
                setMessage(data.message || "Sign up successful.");
                window.location.href = "#logform"; // Redirect on success
            } else {
                setMessage(data.message || "An unknown error occurred."); // Update here to use data.message
            }
        } catch (error) {
            console.error("Error during signup:", error);
            setMessage("An error occurred. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <Head>
                <meta charSet="utf-8" />
                <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <title>UNESWA HEALTH APP</title>
            </Head>
            <div className="background"></div>
            <div className="container">
                <div className="item">
                    <h4 className="logo"> UNESWA MENTAL HEALTH APP</h4>
                    <div className="text-item">
                        <h2>Welcome! <br /><span>{isLogin ? 'Sign In' : 'Sign Up'}</span></h2>
                        <p>In order to access our mental health and awareness resources</p>
                    </div>
                </div>
                <div className="login-section">
                    <div className="form-box login" id="logform">
                        {isLogin ? (
                            <form onSubmit={handleLogin}>
                                <h3>Sign In</h3>
                                {message && <p className='message'>{message}</p>}
                                <div className="input-box">
                                    <span className="icon"><i className='bx bxs-user'></i></span>
                                    <input
                                        type="text"
                                        placeholder="Student ID"
                                        required
                                        value={studentId}
                                        onChange={(e) => setStudentId(e.target.value)}
                                    />
                                    <label>Student ID</label>
                                </div>
                                <div className="input-box">
                                    <span className="icon"><i className='bx bxs-lock-alt'></i></span>
                                    <input
                                        type="password"
                                        placeholder="Password"
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                    <label>Password</label>
                                </div>
                                <button className="btn" type="submit" disabled={loading}>
                                    {loading ? 'Logging In...' : 'Login'}
                                </button>
                                <div className='forgotpassword'>
                                </div>
                                <div className="create-account">
                                    <p>Create A New Account?
                                        <a href="#" onClick={() => setIsLogin(false)}> Sign Up</a>
                                    </p>
                                </div>
                            </form>
                        ) : (
                            <form onSubmit={handleSignUp}>
                                <h3>Sign Up</h3>
                                {message && <p className='message'>{message}</p>}
                                <div className="input-box">
                                    <span className="icon"><i className='bi bi-person'></i></span>
                                    <input
                                        type="text"
                                        placeholder="Student ID"
                                        required
                                        value={studentId}
                                        onChange={(e) => setStudentId(e.target.value)}
                                    />
                                    <label>Student ID</label>
                                </div>
                                <div className="input-box">
                                    <span className="icon"><i className='bi bi-envelope'></i></span>
                                    <input
                                        type="email"
                                        placeholder="Email"
                                        required
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    />
                                    <label>Email</label>
                                </div>
                                <div className="input-box">
                                    <span className="icon"><i className='bi bi-lock'></i></span>
                                    <input
                                        type="password"
                                        placeholder="Password"
                                        required
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                    <label>Password</label>
                                </div>
                                <button className="btn" type="submit" disabled={loading}>
                                    {loading ? 'Signing Up...' : 'Sign Up'}
                                </button>
                                <div className="create-account">
                                    <p>Already Have An Account?
                                        <a href="#" onClick={() => setIsLogin(true)}> Sign In</a>
                                    </p>
                                </div>
                            </form>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}
