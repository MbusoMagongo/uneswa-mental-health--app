<?php
header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');


$conn = new mysqli('localhost', 'root', '', 'campus_health');

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

$data = json_decode(file_get_contents("php://input"), true);
$eventId = $data['eventId'] ?? '';
$studentId = $data['studentId'] ?? ''; 

if (empty($eventId) || empty($studentId)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO reservations (event_id, student_id) VALUES (?, ?)");
$stmt->bind_param("is", $eventId, $studentId); 

if ($stmt->execute()) {
    
    $notificationStmt = $conn->prepare("INSERT INTO notifications (type, related_id) VALUES ('reservation', ?)");
    $notificationStmt->bind_param("i", $eventId);
    
    if ($notificationStmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Reservation successful and notification added.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Reservation successful but notification failed.']);
    }

    $notificationStmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Reservation failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>